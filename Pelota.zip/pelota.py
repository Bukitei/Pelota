import sys, pygame

# Inicializamos
pygame.init()

# Resolución de 800x600
width = 800
height = 600
size = width, height
screen = pygame.display.set_mode(size)

# Título de la ventana
pygame.display.set_caption("Juego ejemplo con Pygame por Borja")

# Empezamos el juego

# Necesitamos ciertas cosas

speed = [1,1] # Velocidad en modo lista (x,y)
white = 255, 255, 255 # Color blanco del fondo

ball = pygame.image.load("ball.png") # Cargamos nuestra imagen
ballrect = ball.get_rect()

bar = pygame.image.load("bar.png") # Cargamos la barra
barrect = bar.get_rect()
barrect.move_ip(400, 260) # Movemos la barra a la mitad

run=True
while run:

	# Esperamos a que se mueva un poco la bola (ms)
	pygame.time.delay(2)
	# Captura de eventos
	for event in pygame.event.get():
		# Si el jugador quiere salir, salimos
		if event.type == pygame.QUIT: run = False

	# Veamos la barra
	keys = pygame.key.get_pressed()
	if keys[pygame.K_UP]:
		barrect=barrect.move(0,-1)
	if keys[pygame.K_DOWN]:
		barrect=barrect.move(0,1)
		
	# Colisión de la pelota con la barra
	if barrect.colliderect(ballrect):
		speed[0] = -speed[0]
	
	# Movemos la pelota
	ballrect = ballrect.move(speed);
	
	# Nos aseguramos que la pelota no se sale de la ventana
	if ballrect.left < 0 or ballrect.right > width:
		speed[0] = -speed[0] # Simulamos el rebote
	if ballrect.top < 0 or ballrect.bottom > height:
		speed[1] = -speed[1] # Simulamos el rebote
		
	# Ahora el fondo
	screen.fill(white)
	screen.blit(ball, ballrect)
	screen.blit(bar, barrect)
	pygame.display.flip()
	
#Salimos
pygame.quit()